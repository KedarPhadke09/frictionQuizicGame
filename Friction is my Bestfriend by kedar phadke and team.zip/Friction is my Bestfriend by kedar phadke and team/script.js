const questions = [
    {
        question: "What is the coefficient of friction for dry wood on wood?",
        options: ["0.1", "0.3", "0.5", "0.7", "1.0", "1.2"],
        answer: 2
    },
    {
        question: "What type of friction occurs between moving surfaces?",
        options: ["Static", "Sliding", "Rolling", "Fluid", "Air", "Static and rolling"],
        answer: 1
    },
    {
        question: "What reduces friction between two surfaces?",
        options: ["Increasing weight", "Lubrication", "Making surfaces rough", "Increasing speed", "Using dry surfaces", "Adding salt"],
        answer: 1
    },
    {
        question: "What is the unit of frictional force?",
        options: ["Joule", "Newton", "Watt", "Pascal", "Volt", "Ampere"],
        answer: 1
    },
    {
        question: "Which material would have the highest coefficient of friction with rubber?",
        options: ["Ice", "Wood", "Concrete", "Plastic", "Steel", "Glass"],
        answer: 2
    },
    {
        question: "What type of force is friction?",
        options: ["Electromagnetic", "Gravitational", "Contact", "Nuclear", "Centripetal", "Electrostatic"],
        answer: 2
    },
    {
        question: "Which friction acts on an object at rest?",
        options: ["Static friction", "Sliding friction", "Rolling friction", "Fluid friction", "Dynamic friction", "Negative friction"],
        answer: 0
    },
    {
        question: "What happens to friction when the weight of an object increases?",
        options: ["Increases", "Decreases", "Remains constant", "Becomes zero", "Inversely proportional", "Unaffected"],
        answer: 0
    },
    {
        question: "In which direction does friction act relative to motion?",
        options: ["Same direction", "Opposite direction", "Perpendicular", "None", "Circular path", "At an angle"],
        answer: 1
    },
    {
        question: "Which friction is the weakest?",
        options: ["Static friction", "Sliding friction", "Rolling friction", "Fluid friction", "Air friction", "Surface friction"],
        answer: 2
    },
    {
        question: "What type of friction is air resistance?",
        options: ["Static friction", "Sliding friction", "Rolling friction", "Fluid friction", "Solid friction", "Kinetic friction"],
        answer: 3
    },
    {
        question: "What factor does not affect friction between two surfaces?",
        options: ["Surface roughness", "Normal force", "Weight of object", "Contact area", "Surface material", "Temperature"],
        answer: 3
    },
    {
        question: "Which of these surfaces has the highest coefficient of friction?",
        options: ["Glass", "Polished metal", "Rubber on asphalt", "Ice", "Water", "Plastic"],
        answer: 2
    },
    {
        question: "Which factor increases rolling friction?",
        options: ["Decreasing surface area", "Increasing lubrication", "Adding weight", "Using softer material", "Reducing surface smoothness", "Lowering temperature"],
        answer: 2
    },
    {
        question: "What is kinetic friction?",
        options: ["Friction at rest", "Friction in motion", "Friction in water", "Friction with air", "Friction with reduced force", "Static force"],
        answer: 1
    },
    {
        question: "What force is necessary to overcome to start moving an object?",
        options: ["Kinetic friction", "Static friction", "Rolling friction", "Fluid friction", "Force of gravity", "Magnetic force"],
        answer: 1
    },
    {
        question: "What happens to static friction as applied force increases?",
        options: ["Decreases", "Increases until maximum", "Remains constant", "Becomes kinetic", "Decreases after maximum", "Turns zero"],
        answer: 1
    },
    {
        question: "Which of these has the lowest coefficient of friction?",
        options: ["Rubber on concrete", "Steel on steel", "Teflon on steel", "Ice on ice", "Wood on wood", "Plastic on metal"],
        answer: 2
    },
    {
        question: "What is a common method to reduce friction in machinery?",
        options: ["Use more weight", "Use rougher surfaces", "Apply lubrication", "Use smaller parts", "Add adhesive", "Increase temperature"],
        answer: 2
    },
    {
        question: "Which of these statements is true about friction?",
        options: ["Friction depends on speed", "Friction acts only on liquids", "Friction is a non-contact force", "Friction resists relative motion", "Friction is constant in all conditions", "Friction causes movement"],
        answer: 3
    }
];

// All other JavaScript code (e.g., `loadQuestion`, `selectOption`, and other functions) remains the same as the previous example.


let currentQuestionIndex = 0;
let score = 0;

// Elements
const questionTitle = document.getElementById("question-title");
const optionsContainer = document.getElementById("options-container");
const nextButton = document.getElementById("next-button");
const restartButton = document.getElementById("restart-button");
const creditsButton = document.getElementById("credits-button");
const creditsSection = document.getElementById("credits");
const popup = document.getElementById("popup");
const popupContent = document.getElementById("popup-content");
const popupClose = document.getElementById("popup-close");
const closeCreditsButton = document.getElementById("close-credits-button");

// Load the current question
function loadQuestion() {
    const questionData = questions[currentQuestionIndex];
    questionTitle.textContent = questionData.question;
    optionsContainer.innerHTML = questionData.options
        .map((option, index) => `<button class="option" onclick="selectOption(${index})">${option}</button>`)
        .join("");
}

// Handle answer selection
function selectOption(selectedIndex) {
    const questionData = questions[currentQuestionIndex];
    if (selectedIndex === questionData.answer) {
        score += 5;
        alert("Correct! +5 points.");
    } else {
        score -= 1;
        alert("Incorrect! -1 point.");
    }
    nextButton.style.display = "inline";
}

// Move to the next question
nextButton.onclick = () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
        nextButton.style.display = "none";
    } else {
        showPopup(`Quiz Complete! Final Score: ${score}`);
        nextButton.style.display = "none";
        restartButton.style.display = "inline";
    }
};

// Restart the game
restartButton.onclick = () => {
    currentQuestionIndex = 0;
    score = 0;
    loadQuestion();
    nextButton.style.display = "none";
    restartButton.style.display = "none";
};

// Show credits
creditsButton.onclick = () => {
    creditsSection.style.display = "block";
};

// Close credits
closeCreditsButton.onclick = () => {
    creditsSection.style.display = "none";
};

// Show popup message
function showPopup(message) {
    popupContent.textContent = message;
    popup.style.display = "block";
}

// Close popup
popupClose.onclick = () => {
    popup.style.display = "none";
};

// Initialize first question
loadQuestion();
